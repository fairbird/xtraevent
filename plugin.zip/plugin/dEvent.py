# -*- coding: utf-8 -*-
# by digiteng...12-2019
#  <widget source="session.Event_Now" render="Label" position="50,545" size="930,40" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="center">
#   	<convert type="dEvent">SESSION_EPISODE,RATING</convert>
# </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
#from enigma import eEPGCache
from Components.Converter.genre import getGenreStringSub
import re

class dEvent(Converter, object):

	SESSION_EPISODE = "SESSION_EPISODE"
	RATING = "RATING"
	YEAR = "YEAR"
	GENRE = "GENRE"

	def __init__(self, type):
		Converter.__init__(self, type)
		self.types = str(type).split(",")

	@cached
	def getText(self):
		event = self.source.event
		if event:
			if self.types:
				evnt = []
				try:
					for type in self.types:
						type.strip()

						if type == self.SESSION_EPISODE:
							ses_ep = self.sessionEpisode(event)
							if len(ses_ep) > 0:
								evnt.append(ses_ep)

						elif type == self.RATING:
							rating = event.getParentalData()
							if rating:
								rtng = rating.getRating()
								if rtng > 0:
									evnt.append("%d+" % (rtng))

						elif type == self.YEAR:
							year = self.year(event)
							if len(year) > 0:
								evnt.append(year)

						elif type == self.GENRE:
							genre = event.getGenreData()
							gnr = getGenreStringSub(genre.getLevel1(), genre.getLevel2())
							if len(gnr) > 0:
								evnt.append(gnr)

					return " ● ".join(evnt)
				except:
					return ""
		return ""
	text = property(getText)

	def sessionEpisode(self, event):
		fd = event.getShortDescription() + "\n" + event.getExtendedDescription()
		pattern = ["(\d+). Staffel, Folge (\d+)", "T(\d+) Ep.(\d+)"]
		for i in pattern:
			seg = re.search(i, fd)
			if seg:
				s = seg.group(1).zfill(2)
				e = seg.group(2).zfill(2)
				return 'S%sE%s' % (s, e)
		return ""

	def year(self, event):
		fd = event.getShortDescription() + "\n" + event.getExtendedDescription()
		pattern = [".*[A-Z][A-Z]* (\d+)", "\([+][0-9]+\)\s((\d+)(\d+)+)"]
		for i in pattern:
			yr = re.search(i, fd)
			if yr:
				jr = yr.group()
				return "%s"%(jr)
		return ""
