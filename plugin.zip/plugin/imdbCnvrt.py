# -*- coding: utf-8 -*-
# by digiteng...12-2019

from Components.Converter.Converter import Converter
from Components.Element import cached
import urllib2
import re


class imdbCnvrt(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return ""

		if not event is None:
			if self.type == "imdbRating":
				evnt = event.getEventName()
				year = self.yearPr(event)
				if year != "":
					evnt = event.getEventName() + " " + year
				film = re.sub('\s+', '+', evnt)
				open("/tmp/evnt.txt", "w").write(film)
				try:
					url = 'https://www.imdb.com/find?q=%s&s=tt&site=aka' % film
					req = urllib2.Request(url)
					resp = urllib2.urlopen(req)
					respData = resp.read()
					pc = re.compile('<tr class="findResult (?:odd|even)">.*?<td class="result_text"> <a href="/title/(tt\\d{7,7})/.*?"\\s?>(.*?)</a>.*?</td>', re.DOTALL)
					pr = pc.search(str(respData))
					id = pr.group(1)

					url = 'https://www.imdb.com/title/%s/?ref_=fn_tt_tt_1'%id
					req = urllib2.Request(url)
					resp = urllib2.urlopen(req)
					respData = resp.read()
					pc = re.compile('<span itemprop="ratingValue">(.*?)</span>', re.DOTALL)
					pr = pc.search(str(respData))
					return "imdb : " + pr.group(1)


				except:
					pass
		else:
			pass
	text = property(getText)
	
	def yearPr(self, event):
		fd = event.getShortDescription() + "\n" + event.getExtendedDescription()
		#open("/tmp/evnt.txt", "w").write(fd)
		pattern = [".*[A-Z][A-Z]*\s(\d+)+", "\([+][0-9]+\)\s((\d+)(\d+)+)"]
		for i in pattern:
			yr = re.search(i, fd)
			if yr:
				jr = yr.group(1)
				return "%s"%jr
		return ""
		
		
	def downloadFinished(self, total, string=''):
		return "end"
	
	def downloadFailed(self, failure_instance=None, error_message=''):
		return "err"
	
	
	
	
	
	
	