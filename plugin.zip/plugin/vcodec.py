# -*- coding: UTF-8 -*-

from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eServiceCenter, eServiceReference, iServiceInformation
from Poll import Poll


class vcodec(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return ""
		info = service and service.info()
		if not info:
			return ""
		
		if self.type == "videocodec":
            from Components.Converter.PliExtraInfo import codec_data
            text = codec_data.get(self.info.getInfo(iServiceInformation.sVideoType), 'N/A')
			return text

	text = property(getText)
