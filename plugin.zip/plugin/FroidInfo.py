# by digiteng...10-2019
#  <widget source="global.CurrentTime" render="Label" position="50,243" size="930,300" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="top">
#    <convert type="FroidInfo" />
#  </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
import os
from os import path, popen

class FroidInfo(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):
		# cpu
		if os.path.exists("/proc/loadavg"):
			f = open("/proc/loadavg", "r")
			c = f.read(4)
			f.close()
			cpu = "Cpu : % " + c
		if os.path.exists("/proc/cpuinfo"):
			ci = open("/proc/cpuinfo", "r")
			cc = ci.readlines()
			ci.close()
			for i in cc:
				cc = i.split()
				ccc = i.split()
				if cc[0] == "cpu":
					if ccc[1] == "type":
						cpuin = ccc[3]
					if ccc[1] == "MHz":
						cpuf = ccc[3]                   
						cpuname = cpuin + " ( " + cpuf +"MHz )"
		#ram
		if os.path.exists("/proc/meminfo"):
			f = open("/proc/meminfo", "r")
			m = f.readlines()
			f.close()
			for i in m:
				m = i.split()
				if m[0] == "MemTotal:":
					mtotal = str(int(m[1])/1000 )
					mtotal = ("%s MB ") % mtotal
				if m[0] == "MemFree:":
					mfree = str(int(m[1])/1000 )
					mfree = ("RAM : %s") % mfree
					ram = mfree + " / " + mtotal + "(free/total)"
		# flash
		ffr = popen("df -m").readlines()
		for i in ffr:
			ff = i.split()
			if ff[5] == '/':
				ftotal = ff[1]
				ffree = ff[3]
				flash = "Flash : " + ffree + " / " + ftotal + " MB (free/total)"
			if ff[5] == '/media/hdd':
				ht = ff[1]
				hf = ff[3]
				hdd = "HDD : " + hf + " / " + ht + " MB (free/total)"

		return cpu + " " + cpuname + "\n\n" + ram + "\n\n" + flash + "\n\n" + hdd

	text = property(getText)
