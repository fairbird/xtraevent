# -*- coding: utf-8 -*-
# by digiteng...01.2020

from Components.Converter.Converter import Converter
from Components.Element import cached
import json
import re
import os
import urllib2
from urllib import quote_plus

year = ""
api = "b1538d0b"

if not os.path.isdir('/media/hdd/poster'):
	os.mkdir('/media/hdd/poster')

class infoMovie(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return ""
		if not event is None:
			film = event.getEventName()
			url = 'https://www.omdbapi.com/?t=%s&y=%s&apikey=%s' %(quote_plus(film), year, api)
			jj = json.load(urllib2.urlopen(url))
			if self.type == "RATING":
				
				try:
					j2 = (jj['imdbRating'])
					if j2 != '':
						return "imdb : " + j2
				except:
					return ""
		else:
			return ""
	text = property(getText)
