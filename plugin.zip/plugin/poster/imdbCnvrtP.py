# -*- coding: utf-8 -*-
# by digiteng...01-2020

from Components.Converter.Converter import Converter
from Components.Element import cached
import urllib2
import re
from urllib import pathname2url



class imdbCnvrtP(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return ''

		if not event is None:
			if self.type == 'imdbRating':
				evnt = event.getEventName()

				try:
					ff = pathname2url(evnt)
					url = 'http://imdb.com/find?q=' + ff + '&s=tt&site=aka'
					req = urllib2.Request(url)
					resp = urllib2.urlopen(req)
					respData = resp.read()
					pc = re.compile('<tr class="findResult (?:odd|even)">.*?<td class="result_text"> <a href="/title/(tt\\d{7,7})/.*?"\\s?>(.*?)</a>.*?</td>', re.DOTALL)
					pr = pc.search(respData)

					id = pr.group(1)
					url = 'https://www.imdb.com/title/%s/?ref_=fn_tt_tt_1'%id

					req = urllib2.Request(url)
					resp = urllib2.urlopen(req)
					respData = resp.read()
					pc = re.compile('<span itemprop="ratingValue">(.*?)</span>', re.DOTALL)
					pr = pc.search(str(respData))
					return "imdb : " + pr.group(1)

				except:
					pass
		else:
			pass
	text = property(getText)
