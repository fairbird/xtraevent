# -*- coding: utf-8 -*-
# by digiteng...12-2019

from Components.Converter.Converter import Converter
from Components.Element import cached
import json
import re
import os
import urllib2



if not os.path.isdir('/media/hdd/poster'):
	os.mkdir('/media/hdd/poster')

class omdbRtng(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		event = self.source.event
		if event is None:
			return ""

		if not event is None:
			if self.type == "RATING":
				evnt = event.getEventName()
				try:
					ffilm = re.sub('\s+', '+', evnt)
					url = 'https://www.omdbapi.com/?t=%s&apikey=b1538d0b' %(ffilm)
					jjj = json.load(urllib2.urlopen(url))
					rtng = (jjj['imdbRating'])
					return "imdb : " + rtng
				except:
					pass
		else:
			return ""
	text = property(getText)
