# by digiteng...07-2019
#	<widget source="session.CurrentService" render="Pixmap" pixmap="LiteHD/buttons/green.png" position="755,100" zPosition="2" size="30,30" transparent="1" alphatest="blend">
#      <convert type="intCheck" />
#      <convert type="ConditionalShowHide" />
#    </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached
import urllib2


class FroidintCheck(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def net(self):

		try:
			urllib2.urlopen('http://216.58.206.164', timeout=0.3)
			return True
		except urllib2.URLError as err: pass
		return False

	boolean = property(net)