# -*- coding: utf-8 -*-
# by digiteng...
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger,ConfigOnOff, ConfigSlider
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from os import environ, listdir, remove, rename, system, popen
from skin import parseColor
from Components.Label import Label


config.plugins.FroidSetup = ConfigSubsection()

colors = []
colors.append(('DEFAULT', _('DEFAULT')))
colors.append(('BACKGROUND', _('BACKGROUND')))                        #1
colors.append(('TITLE BACKGROUND', _('TITLE BACKGROUND'))) #2
colors.append(('TITLE FONT', _('TITLE FONT')))                                     #2a
colors.append(('TITLE LINE', _('TITLE LINE')))                                         #2b
colors.append(('OTHER LINE', _('OTHER LINE')))                                    #3
colors.append(('SELECT BAR', _('SELECT BAR')))                              #4
colors.append(('PROGRESS', _('PROGRESS')))                                   #5
colors.append(('PROGRESS SEL', _('PROGRESS SEL')))                 #5a
colors.append(('SCROLLBAR', _('SCROLLBAR')))                                #6
colors.append(('FONT', _('FONT')))                                                           #7
colors.append(('FONT SELECT', _('FONT SELECT')))                         #8
colors.append(('RGYB BACKGROUND', _('RGYB BACKGROUND'))) #9
colors.append(('CLOCK', _('CLOCK')))                                                    #10
colors.append(('SERVICE DESCRIPTION', _('SERVICE DESCRIPTION')))  #12
colors.append(('SERVICE DESCRIPTION SEL', _('SERVICE DESCRIPTION SEL')))  #12a
colors.append(('BUTTON COLOR', _('BUTTON COLOR')))  #13
colors.append(('INFOBAR INFO', _('INFOBAR INFO')))  #14

mntv = []
mntv.append(("nopig"))
mntv.append(("pig"))

mntv2 = []
mntv2.append(("pig2", _(True)))
mntv2.append(("Nopig2", _(False)))

infmntv = []
infmntv.append(("Noinfo_ch"))
infmntv.append(("info_ch"))

clkmntv = []
clkmntv.append(("Noclk_mn"))
clkmntv.append(("clk_mn"))

mvmntv = []
mvmntv.append(("movie_m2"))
mvmntv.append(("movie_df"))

trns = []
trns.append(("#00", _("% 0")))
trns.append(("#10", _("% 10")))
trns.append(("#20", _("% 20")))
trns.append(("#30", _("% 30")))
trns.append(("#50", _("% 50")))


ttllnsz = []
ttllnsz.append(("1", _("1")))
ttllnsz.append(("2", _("2")))
ttllnsz.append(("3", _("3")))
ttllnsz.append(("4", _("4")))
ttllnsz.append(("7", _("7")))

style_clock = []
style_clock.append(("Console; 38", _("Default")))
style_clock.append(("LCD; 46", _("Digital")))
style_clock.append(("cnfg; 45", _("Symbol")))
style_clock.append(("analog", _("Analog")))

style_inf = []
style_inf.append(('default', _('Default')))
style_inf.append(('i2', _('Infobar 2')))
style_inf.append(('i3', _('Infobar 3')))
style_inf.append(('lite', _('Infobar Lite')))
style_inf.append(('slimlite', _('Infobar Slim Lite')))
style_inf.append(('name', _('Infobar Just Name')))


style_Sinf = []
style_Sinf.append(('deff', _('Default')))
style_Sinf.append(('classic', _('SecondInfoBar Classic')))
style_Sinf.append(('s2', _('SecondInfoBar 2')))

style_ch = []
style_ch.append(('def', _('Default')))
style_ch.append(('ch2', _('Style 2')))
style_ch.append(('ch3', _('Style 3')))
style_ch.append(('ch4', _('Style 4')))
style_ch.append(('ch5', _('Style 5')))

style_vol = []
style_vol.append(('Volume', _('Default')))
style_vol.append(('lume', _('Volume 2')))
style_vol.append(('me', _('Volume 3')))
style_vol.append(('olume', _('Volume 4')))

style_history = []
style_history.append(('history_def', _('Default')))
style_history.append(('history_mini', _('History Mini')))

style_emc = []
style_emc.append(('emc_def', _('Default')))
style_emc.append(('emc_bigcover', _('EMC Big Cover')))

style_weather = []
style_weather.append(('weathericon', _('Default')))
style_weather.append(('weathericon2', _('Weather Icons Normal')))

style_infobar_weather = []
style_infobar_weather.append(('wx', _('Default')))
style_infobar_weather.append(('weather-mini', _('Weather Infobar Mini')))
style_infobar_weather.append(('weather', _('Weather Infobar')))

style_event = []
style_event.append(('_evnt', _('Default')))
style_event.append(('_2', _('Running Info')))

rgyb = []
rgyb.append(('_rgyb', _('Default')))
rgyb.append(('_r1', _('RGYB 1')))
rgyb.append(('_r2', _('RGYB 2')))
rgyb.append(('_r3', _('RGYB 3')))
rgyb.append(('_r4', _('RGYB 4')))

sel_line = []
sel_line.append(('line', _('Default')))
sel_line.append(('black', _('black')))
sel_line.append(('grey', _('grey')))
sel_line.append(('red', _('red')))
sel_line.append(('blue', _('blue')))
sel_line.append(('green', _('green')))
sel_line.append(('cyan', _('cyan')))
sel_line.append(('yellow', _('yellow')))
sel_line.append(('yellow2', _('yellow2')))


bootlogom = []
bootlogom.append(('bdef', _('Default')))
bootlogom.append(('b1', _('Bootlogo 1')))
bootlogom.append(('b2', _('Bootlogo 2')))
bootlogom.append(('b3', _('Bootlogo 3')))
bootlogom.append(('b4', _('Bootlogo 4')))
bootlogom.append(('b5', _('Bootlogo 5')))
bootlogom.append(('b6', _('Bootlogo 6')))
bootlogom.append(('b7', _('Bootlogo 7')))
bootlogom.append(('b8', _('Bootlogo 8')))
bootlogom.append(('b9', _('Bootlogo 9')))
bootlogom.append(('b10', _('Bootlogo 10')))
bootlogom.append(('b11', _('Bootlogo 11')))
bootlogom.append(('b12', _('Bootlogo 12')))
bootlogom.append(('b13', _('Bootlogo 13')))
bootlogom.append(('b14', _('Bootlogo 14')))
bootlogom.append(('b15', _('Bootlogo 15')))
bootlogom.append(('b16', _('Bootlogo 16')))
bootlogom.append(('b17', _('Bootlogo 17')))
bootlogom.append(('b18', _('Bootlogo 18')))
bootlogom.append(('b19', _('Bootlogo 19')))
bootlogom.append(('b20', _('Bootlogo 20')))
bootlogom.append(('b21', _('Bootlogo 21')))
bootlogom.append(('b22', _('Bootlogo 22')))
bootlogom.append(('b23', _('Bootlogo 23')))
bootlogom.append(('b24', _('Bootlogo 24')))
bootlogom.append(('b25', _('Bootlogo 25')))
bootlogom.append(('b26', _('Bootlogo 26')))
bootlogom.append(('b27', _('Bootlogo 27')))
bootlogom.append(('b28', _('Bootlogo 28')))
bootlogom.append(('b29', _('Bootlogo 29')))
bootlogom.append(('b30', _('Bootlogo 30')))
bootlogom.append(('b31', _('Bootlogo 31')))
bootlogom.append(('b32', _('Bootlogo 32')))
bootlogom.append(('b33', _('Bootlogo 33')))
bootlogom.append(('b34', _('Bootlogo 34')))
bootlogom.append(('b35', _('Bootlogo 35')))
bootlogom.append(('b36', _('Bootlogo 36')))
bootlogom.append(('b37', _('Bootlogo 37')))
bootlogom.append(('b38', _('Bootlogo 38')))
bootlogom.append(('b39', _('Bootlogo 39')))
bootlogom.append(('b40', _('Bootlogo 40')))


radioback = []
radioback.append(('rdef', _('Default')))
radioback.append(('r1', _('Radio 1')))
radioback.append(('r2', _('Radio 2')))
radioback.append(('r3', _('Radio 3')))
radioback.append(('r4', _('Radio 4')))
radioback.append(('r5', _('Radio 5')))

spinner = []
spinner.append(('sdef', _('Default')))
spinner.append(('s1', _('Spinner 1')))
spinner.append(('s2', _('Spinner 2')))
spinner.append(('s3', _('Spinner 3')))
spinner.append(('s4', _('Spinner 4')))
spinner.append(('s5', _('Spinner 5')))

autoupselect = []
autoupselect.append(('All', _('On StartUp + 6h')))
autoupselect.append(('Start_Boot', _('On StartUp')))
autoupselect.append(('21600', _('6h')))

mods = []
mods.append(("froid_default", _("DEFAULT MOD")))
mods.append(("froid_slime", _("SLIME MOD")))

hmenu = []
hmenu.append(("center", _("Horizantal Menu 1")))
hmenu.append(("down", _("Horizantal Menu 2")))

config.plugins.FroidSetup.MODSAVE = ConfigOnOff(default=False)
config.plugins.FroidSetup.MOD = ConfigSelection(default="froid_default", choices = mods)
config.plugins.FroidSetup.skin_default = ConfigOnOff(default=False)
config.plugins.FroidSetup.autoUp = ConfigOnOff(default=False)
config.plugins.FroidSetup.autoUpSel = ConfigSelection(default="Start_Boot", choices = autoupselect)

#config.plugins.FroidSetup.updateIcon = ConfigOnOff(default=False)

config.plugins.FroidSetup.minitv  = ConfigOnOff(default=True)
config.plugins.FroidSetup.onmntv = ConfigSelection(default="nopig", choices = mntv)
config.plugins.FroidSetup.minitv2 = ConfigSelection(default='pig2', choices=mntv2)
config.plugins.FroidSetup.infminitv = ConfigSelection(default="Noinfo_ch", choices = infmntv)
config.plugins.FroidSetup.clkminitv = ConfigSelection(default="Noclk_mn", choices = clkmntv)
config.plugins.FroidSetup.mvminitv = ConfigSelection(default="movie_m2", choices = mvmntv)
config.plugins.FroidSetup.backTransp = ConfigSelection(default="00", choices = trns)
#config.plugins.FroidSetup.titleLine = ConfigSelection(default="NoTline", choices = ttlln)
config.plugins.FroidSetup.titleLnSz = ConfigSelection(default="2", choices = ttllnsz)
#config.plugins.FroidSetup.titleLnClr = ConfigSelection(default="151f2a", choices = ttllnclr)

config.plugins.FroidSetup.clockStyle = ConfigSelection(default="Console; 38", choices = style_clock)
config.plugins.FroidSetup.infStyle = ConfigSelection(default='default', choices=style_inf)
config.plugins.FroidSetup.SinfStyle = ConfigSelection(default='default', choices=style_Sinf)
config.plugins.FroidSetup.chStyle = ConfigSelection(default='def', choices=style_ch)
config.plugins.FroidSetup.volStyle = ConfigSelection(default='Volume', choices=style_vol)
config.plugins.FroidSetup.hstryStyle = ConfigSelection(default='history_def', choices=style_history)
config.plugins.FroidSetup.emcStyle = ConfigSelection(default='emc_def', choices=style_emc)
config.plugins.FroidSetup.weatherStyle = ConfigSelection(default='weathericon', choices=style_weather)
config.plugins.FroidSetup.InfweatherStyle = ConfigSelection(default='wx', choices=style_infobar_weather)
config.plugins.FroidSetup.eventStyle = ConfigSelection(default='evnt', choices=style_event)
config.plugins.FroidSetup.rgybStyle = ConfigSelection(default='rgyb', choices=rgyb)

config.plugins.FroidSetup.selLine = ConfigOnOff(default=False)
config.plugins.FroidSetup.selLineLeft = ConfigSelection(default="", choices = sel_line)
config.plugins.FroidSetup.selLineRight = ConfigSelection(default="", choices = sel_line)
config.plugins.FroidSetup.selLineTop = ConfigSelection(default="", choices = sel_line)
config.plugins.FroidSetup.selLineBottom = ConfigSelection(default="", choices = sel_line)

config.plugins.FroidSetup.hmnStyle = ConfigSelection(default='center', choices=hmenu)

config.plugins.FroidSetup.bootlogoStyle = ConfigSelection(default='bdef', choices=bootlogom)
config.plugins.FroidSetup.radioStyle = ConfigSelection(default='rdef', choices=radioback)
config.plugins.FroidSetup.spinnerStyle = ConfigSelection(default='sdef', choices=spinner)

#config.plugins.FroidSetup.slider_scale = ConfigSelection(default="1", choices = sscl)
config.plugins.FroidSetup.Colored = ConfigSelection(default='DEFAULT', choices=colors)
#BACKGROUND
config.plugins.FroidSetup.colorR = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB = ConfigSlider(default=120, increment=5, limits=(0,255))
#TITLE BACKGROUND
config.plugins.FroidSetup.colorR2 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG2 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB2 = ConfigSlider(default=120, increment=5, limits=(0,255))
#TITLE FONT
config.plugins.FroidSetup.colorR2a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG2a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB2a = ConfigSlider(default=120, increment=5, limits=(0,255))
#TITLE LINE
config.plugins.FroidSetup.colorR2b = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG2b = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB2b = ConfigSlider(default=120, increment=5, limits=(0,255))
#OTHER LINE
config.plugins.FroidSetup.colorR3 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG3 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB3 = ConfigSlider(default=120, increment=5, limits=(0,255))
#SELECT BAR
config.plugins.FroidSetup.colorR4 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG4 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB4 = ConfigSlider(default=120, increment=5, limits=(0,255))
#PROGRESS
config.plugins.FroidSetup.colorR5 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG5 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB5 = ConfigSlider(default=120, increment=5, limits=(0,255))
#PROGRESS SEL
config.plugins.FroidSetup.colorR5a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG5a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB5a = ConfigSlider(default=120, increment=5, limits=(0,255))
#SCROLLBAR
config.plugins.FroidSetup.colorR6 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG6 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB6 = ConfigSlider(default=120, increment=5, limits=(0,255))
#FONT
config.plugins.FroidSetup.colorR7 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG7 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB7 = ConfigSlider(default=120, increment=5, limits=(0,255))
#FONT SELECT
config.plugins.FroidSetup.colorR8 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG8 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB8 = ConfigSlider(default=120, increment=5, limits=(0,255))
#RGYB BACKGROUND
config.plugins.FroidSetup.colorR9 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG9 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB9 = ConfigSlider(default=120, increment=5, limits=(0,255))
#CLOCK
config.plugins.FroidSetup.colorR10 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG10 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB10 = ConfigSlider(default=120, increment=5, limits=(0,255))
#SERVICE DESCRIPTION
config.plugins.FroidSetup.colorR12 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG12 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB12 = ConfigSlider(default=120, increment=5, limits=(0,255))
#SERVICE DESCRIPTION SEL
config.plugins.FroidSetup.colorR12a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG12a = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB12a = ConfigSlider(default=120, increment=5, limits=(0,255))
#BUTTON COLOR
config.plugins.FroidSetup.colorR13 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG13 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB13 = ConfigSlider(default=120, increment=5, limits=(0,255))
#INFOBAR INFO
config.plugins.FroidSetup.colorR14 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorG14 = ConfigSlider(default=120, increment=5, limits=(0,255))
config.plugins.FroidSetup.colorB14 = ConfigSlider(default=120, increment=5, limits=(0,255))
