# -*- coding: utf-8 -*-
# by digiteng...
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools import Notifications
from Screens.ChoiceBox import ChoiceBox
from Screens.Standby import TryQuitMainloop
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger,ConfigOnOff, ConfigSlider, ConfigNothing
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from os import environ, listdir, remove, rename, system, popen
import shutil
from distutils.dir_util import copy_tree
from Components.Sources.CanvasSource import CanvasSource
from Components.MenuList import MenuList
from Components.ActionMap import NumberActionMap
from skin import parseColor
import urllib
import urllib2
import os
import time
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer, getDesktop
from Tools.Directories import SCOPE_CURRENT_SKIN, fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from Components.Slider import Slider
from Components.Ipkg import IpkgComponent
from Screens.Ipkg import Ipkg
from Components.ProgressBar import ProgressBar
from Tools.Downloader import downloadWithProgress
from zipfile import ZipFile
import configs



class FroidAbout(Screen):

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		self['setupActions'] = ActionMap(['SetupActions'], {'cancel': self.cancel}, -2)

	def cancel(self):
		self.close()

class FroidSetup(ConfigListScreen, Screen):
	skin = '''
<screen name="FroidSetup" position="center,center" size="800,100" flags="wfNoBorder" backgroundColor="#00000000">
	<eLabel name="" text="Warning !...please select Froid Skin..." position="0,0" size="800,100" font="Regular; 28" foregroundColor="#00ff0000" backgroundColor="#00000000" zPosition="12" halign="center" valign="center" />
	<eLabel position="0,0" size="800,100" backgroundColor="#00000000" zPosition="11" transparent="0"/>
	<widget name="config" position="0,0" scrollbarMode="showOnDemand" size="590,100" transparent="1"/>
</screen>'''

	def __init__(self, session):
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session

		self["Picture"] = Pixmap()
		self["preview"] = CanvasSource()
		
		list = []
		ConfigListScreen.__init__(self, list)

		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_('Save'))
		self['key_yellow'] = Label(_('Downloads'))
		self['key_blue'] = Label(_('UpdateSkin'))  

		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EventViewActions"],
		{
			"left": self.keyLeft,
			"down": self.keyDown,
			"up": self.keyUp,
			"right": self.keyRight,
			"red": self.exit,
			"green": self.save,
			"yellow": self.downloads,
			"blue": self.UpdateSkin,
			"cancel": self.exit,
			"info": self.about,
		},-1)

  		self["title_bg"] = Label(_(" "))
		self["title_font"] = Label(_(" "))
		self["bg"] = Label(_(" "))
		self["select_bar"] = Label(_(" "))
		self["select_font_color"] = Label(_(" "))
		self["select_csd_color"] = Label(_(" "))
		self["font_clr"] = Label(_(" "))
		self["csd_clr"] = Label(_(" "))
		self["progress_bar"] = Label(_(" "))
		self["select_progress_bar"] = Label(_(" "))
		self["scrool_bar"] = Label(_(" "))
		self["ttl_line"] = Label(_(" "))
		self["othr_line"] = Label(_(" "))
		self["othr_line2"] = Label(_(" "))
		self["clk_color"] = Label(_(" "))
		self["button_color"] = Label(_(" "))
		self["button_color2"] = Label(_(" "))
		self["infobar_info"] = Label(_(" "))
		self["rgyb_bg"] = Label(_(" "))

		self.timer = eTimer()
		self.timer.callback.append(self.FList)
		self.onLayoutFinish.append(self.FList)
		self.onLayoutFinish.append(self.Picture)

	def delay(self):
		self.timer.start(100, True)

	def FList(self):
		for x in self["config"].list:
			if len(x) > 1:
				x[1].save()
		list = []
		list.append(getConfigListEntry(_(" _________________________________  MODS __________________________________"), ))
		list.append(getConfigListEntry(_(" MODS APPLY"), config.plugins.FroidSetup.MODSAVE))
		if config.plugins.FroidSetup.MODSAVE.value == True:
			list.append(getConfigListEntry(_(" Mods"), config.plugins.FroidSetup.MOD))
		if config.plugins.FroidSetup.MODSAVE.value == False:
			list.append(getConfigListEntry(_(" _________________________________ 礑 SYSTEM _________________________________"), ))
			list.append(getConfigListEntry(_(" Skin Setup"), config.plugins.FroidSetup.skin_default))
			list.append(getConfigListEntry(_(" Auto Update"), config.plugins.FroidSetup.autoUp))
			if config.plugins.FroidSetup.autoUp.value == True:
				list.append(getConfigListEntry(_("  Auto Update Check"), config.plugins.FroidSetup.autoUpSel))
			if config.plugins.FroidSetup.skin_default.value == True:
				list.append(getConfigListEntry(_(" _________________________________ 礕 COLORS _________________________________"), ))
				list.append(getConfigListEntry(_(" "), ))
				list.append(getConfigListEntry(_("COLORS"), config.plugins.FroidSetup.Colored))
				list.append(getConfigListEntry(_(" "), ))
				if config.plugins.FroidSetup.Colored.value == "BACKGROUND":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR.value), int(config.plugins.FroidSetup.colorG.value), int(config.plugins.FroidSetup.colorB.value)))
					self.r = '{:02x}'.format(int(config.plugins.FroidSetup.colorR.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB.value))
					rgbclr = "#%s" %self.r
					self["bg"].setText(_("."))
					self["bg"].instance.setBackgroundColor(parseColor(rgbclr))
					self["bg"].instance.setForegroundColor(parseColor(rgbclr))

				if config.plugins.FroidSetup.Colored.value == "TITLE BACKGROUND":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR2))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG2))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB2))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR2.value), int(config.plugins.FroidSetup.colorG2.value), int(config.plugins.FroidSetup.colorB2.value)))
					r2 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR2.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG2.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB2.value))
					rgbclr2 = "#%s" %r2
					self["title_bg"].setText(_("."))
					self["title_bg"].instance.setBackgroundColor(parseColor(rgbclr2))
					self["title_bg"].instance.setForegroundColor(parseColor(rgbclr2))

				if config.plugins.FroidSetup.Colored.value == "TITLE FONT":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR2a))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG2a))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB2a))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR2a.value), int(config.plugins.FroidSetup.colorG2a.value), int(config.plugins.FroidSetup.colorB2a.value)))
					r2a = '{:02x}'.format(int(config.plugins.FroidSetup.colorR2a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG2a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB2a.value))
					rgbclr2a = "#%s" %r2a
					self["title_font"].setText(_("MENU"))
					self["title_font"].instance.setForegroundColor(parseColor(rgbclr2a))
				
				if config.plugins.FroidSetup.Colored.value == "TITLE LINE":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR2b))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG2b))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB2b))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR2b.value), int(config.plugins.FroidSetup.colorG2b.value), int(config.plugins.FroidSetup.colorB2b.value)))
					r2b = '{:02x}'.format(int(config.plugins.FroidSetup.colorR2b.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG2b.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB2b.value))
					rgbclr2b = "#%s" %r2b
					self["ttl_line"].setText(_("."))
					self["ttl_line"].instance.setBackgroundColor(parseColor(rgbclr2b))
					self["ttl_line"].instance.setForegroundColor(parseColor(rgbclr2b))

				if config.plugins.FroidSetup.Colored.value == "OTHER LINE":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR3))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG3))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB3))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR3.value), int(config.plugins.FroidSetup.colorG3.value), int(config.plugins.FroidSetup.colorB3.value)))
					r3 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR3.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG3.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB3.value))
					rgbclr3 = "#%s" %r3
					self["othr_line"].setText(_("."))
					self["othr_line"].instance.setBackgroundColor(parseColor(rgbclr3))
					self["othr_line"].instance.setForegroundColor(parseColor(rgbclr3))
					self["othr_line2"].setText(_("."))
					self["othr_line2"].instance.setBackgroundColor(parseColor(rgbclr3))
					self["othr_line2"].instance.setForegroundColor(parseColor(rgbclr3))

				if config.plugins.FroidSetup.Colored.value == "SELECT BAR":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR4))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG4))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB4))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR4.value), int(config.plugins.FroidSetup.colorG4.value), int(config.plugins.FroidSetup.colorB4.value)))
					r4 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR4.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG4.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB4.value))
					rgbclr4 = "#%s" %r4
					self["select_bar"].setText(_("."))
					self["select_bar"].instance.setBackgroundColor(parseColor(rgbclr4))
					self["select_bar"].instance.setForegroundColor(parseColor(rgbclr4))

				if config.plugins.FroidSetup.Colored.value == "PROGRESS":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR5))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG5))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB5))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR5.value), int(config.plugins.FroidSetup.colorG5.value), int(config.plugins.FroidSetup.colorB5.value)))
					r5 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR5.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG5.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB5.value))
					rgbclr5 = "#%s" %r5
					self["progress_bar"].setText(_("."))
					self["progress_bar"].instance.setBackgroundColor(parseColor(rgbclr5))
					self["progress_bar"].instance.setForegroundColor(parseColor(rgbclr5))

				if config.plugins.FroidSetup.Colored.value == "PROGRESS SEL":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR5a))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG5a))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB5a))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR5a.value), int(config.plugins.FroidSetup.colorG5a.value), int(config.plugins.FroidSetup.colorB5a.value)))
					r5a = '{:02x}'.format(int(config.plugins.FroidSetup.colorR5a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG5a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB5a.value))
					rgbclr5a = "#%s" %r5a
					self["select_progress_bar"].setText(_("."))
					self["select_progress_bar"].instance.setBackgroundColor(parseColor(rgbclr5a))
					self["select_progress_bar"].instance.setForegroundColor(parseColor(rgbclr5a))					

				if config.plugins.FroidSetup.Colored.value == "SCROLLBAR":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR6))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG6))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB6))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR6.value), int(config.plugins.FroidSetup.colorG6.value), int(config.plugins.FroidSetup.colorB6.value)))
					r6 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR6.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG6.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB6.value))
					rgbclr6 = "#%s" %r6
					self["scrool_bar"].setText(_("."))
					self["scrool_bar"].instance.setBackgroundColor(parseColor(rgbclr6))
					self["scrool_bar"].instance.setForegroundColor(parseColor(rgbclr6))

				if config.plugins.FroidSetup.Colored.value == "FONT":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR7))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG7))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB7))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR7.value), int(config.plugins.FroidSetup.colorG7.value), int(config.plugins.FroidSetup.colorB7.value)))
					r7 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR7.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG7.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB7.value))
					rgbclr7 = "#%s" %r7
					self["font_clr"].setText(_("BBC HD"))
					self["font_clr"].instance.setForegroundColor(parseColor(rgbclr7))

				if config.plugins.FroidSetup.Colored.value == "FONT SELECT":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR8))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG8))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB8))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR8.value), int(config.plugins.FroidSetup.colorG8.value), int(config.plugins.FroidSetup.colorB8.value)))
					r8 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR8.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG8.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB8.value))
					rgbclr8 = "#%s" %r8
					self["select_font_color"].setText(_("BBC HD"))
					self["select_font_color"].instance.setForegroundColor(parseColor(rgbclr8))

				if config.plugins.FroidSetup.Colored.value == "RGYB BACKGROUND":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR9))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG9))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB9))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR9.value), int(config.plugins.FroidSetup.colorG9.value), int(config.plugins.FroidSetup.colorB9.value)))
					r9 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR9.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG9.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB9.value))
					rgbclr9 = "#%s" %r9
					self["rgyb_bg"].setText(_("."))
					self["rgyb_bg"].instance.setBackgroundColor(parseColor(rgbclr9))
					self["rgyb_bg"].instance.setForegroundColor(parseColor(rgbclr9))

				if config.plugins.FroidSetup.Colored.value == "CLOCK":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR10))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG10))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB10))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR10.value), int(config.plugins.FroidSetup.colorG10.value), int(config.plugins.FroidSetup.colorB10.value)))
					r10 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR10.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG10.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB10.value))
					rgbclr10 = "#%s" %r10
					self["clk_color"].setText(_("12:00"))
					self["clk_color"].instance.setForegroundColor(parseColor(rgbclr10))

				if config.plugins.FroidSetup.Colored.value == "SERVICE DESCRIPTION":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR12))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG12))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB12))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR12.value), int(config.plugins.FroidSetup.colorG12.value), int(config.plugins.FroidSetup.colorB12.value)))
					r12 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR12.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG12.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB12.value))
					rgbclr12 = "#%s" %r12
					self["csd_clr"].setText(_("qwertyuıopasdfghjklzxcvbnm"))
					self["csd_clr"].instance.setForegroundColor(parseColor(rgbclr12))

				if config.plugins.FroidSetup.Colored.value == "SERVICE DESCRIPTION SEL":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR12a))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG12a))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB12a))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR12a.value), int(config.plugins.FroidSetup.colorG12a.value), int(config.plugins.FroidSetup.colorB12a.value)))
					r12a = '{:02x}'.format(int(config.plugins.FroidSetup.colorR12a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG12a.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB12a.value))
					rgbclr12a = "#%s" %r12a
					self["select_csd_color"].setText(_("qwertyuıopasdfghjklzxcvbnm"))
					self["select_csd_color"].instance.setForegroundColor(parseColor(rgbclr12a))

				if config.plugins.FroidSetup.Colored.value == "BUTTON COLOR":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR13))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG13))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB13))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR13.value), int(config.plugins.FroidSetup.colorG13.value), int(config.plugins.FroidSetup.colorB13.value)))	
					r13 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR13.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG13.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB13.value))
					rgbclr13 = "#%s" %r13
					self["button_color"].setText(_("Č"))
					self["button_color"].instance.setForegroundColor(parseColor(rgbclr13))
					self["button_color2"].setText(_("Č"))
					self["button_color2"].instance.setForegroundColor(parseColor(rgbclr13))

				if config.plugins.FroidSetup.Colored.value == "INFOBAR INFO":
					list.append(getConfigListEntry(_("Red"), config.plugins.FroidSetup.colorR14))
					list.append(getConfigListEntry(_("Green"), config.plugins.FroidSetup.colorG14))
					list.append(getConfigListEntry(_("Blue"), config.plugins.FroidSetup.colorB14))
					self.cslider(self.RGB(int(config.plugins.FroidSetup.colorR14.value), int(config.plugins.FroidSetup.colorG14.value), int(config.plugins.FroidSetup.colorB14.value)))				
					r14 = '{:02x}'.format(int(config.plugins.FroidSetup.colorR14.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorG14.value)) + '{:02x}'.format(int(config.plugins.FroidSetup.colorB14.value))
					rgbclr14 = "#%s" %r14
					self["infobar_info"].setText(_("Ｓ"))
					self["infobar_info"].instance.setForegroundColor(parseColor(rgbclr14))

				list.append(getConfigListEntry(_(" "), ))
				list.append(getConfigListEntry(_(" _________________________________ 礒 STYLES _________________________________"), ))		
				list.append(getConfigListEntry(_(" 礐 miniTV"), config.plugins.FroidSetup.minitv))	
				if config.plugins.FroidSetup.minitv.value == False:
					list.append(getConfigListEntry(_("   >> Background Transparency"), config.plugins.FroidSetup.backTransp))
					list.append(getConfigListEntry(_("___________________________________________________________________________"), ))
				list.append(getConfigListEntry(_(" _  Title Line Size"), config.plugins.FroidSetup.titleLnSz))
				list.append(getConfigListEntry(_(" 礵 Clock Style"), config.plugins.FroidSetup.clockStyle))
				list.append(getConfigListEntry(_(' 礩 Infobar Style'), config.plugins.FroidSetup.infStyle))
				list.append(getConfigListEntry(_(' 礰 Second Infobar Style'), config.plugins.FroidSetup.SinfStyle))
				list.append(getConfigListEntry(_('  Channel Selection Style'), config.plugins.FroidSetup.chStyle))
				list.append(getConfigListEntry(_('  Volume Style'), config.plugins.FroidSetup.volStyle))	
				list.append(getConfigListEntry(_(' 礳 History Style'), config.plugins.FroidSetup.hstryStyle))	
				list.append(getConfigListEntry(_(' 礔  EMC Style'), config.plugins.FroidSetup.emcStyle))	
				list.append(getConfigListEntry(_('   Weather Icon Style'), config.plugins.FroidSetup.weatherStyle))
				list.append(getConfigListEntry(_('   Weather Infobar Style'), config.plugins.FroidSetup.InfweatherStyle))
				list.append(getConfigListEntry(_(' 礰 Event Info Style'), config.plugins.FroidSetup.eventStyle))
				list.append(getConfigListEntry(_(' 礰 RGYB Style'), config.plugins.FroidSetup.rgybStyle))
				list.append(getConfigListEntry(_(' = SEL BAR LINE'), config.plugins.FroidSetup.selLine))
				if config.plugins.FroidSetup.selLine.value == True:
					list.append(getConfigListEntry(_('      LEFT'), config.plugins.FroidSetup.selLineLeft))
					list.append(getConfigListEntry(_('      RIGHT'), config.plugins.FroidSetup.selLineRight))
					list.append(getConfigListEntry(_('      TOP'), config.plugins.FroidSetup.selLineTop))
					list.append(getConfigListEntry(_('      BOTTOM'), config.plugins.FroidSetup.selLineBottom))
				list.append(getConfigListEntry(_(' = Hor. Menu Style'), config.plugins.FroidSetup.hmnStyle))
				
				list.append(getConfigListEntry(_(" _________________________________  EXTRAS_________________________________"), ))	
				list.append(getConfigListEntry(_('   BootLogos'), config.plugins.FroidSetup.bootlogoStyle))
				list.append(getConfigListEntry(_('   Radio Background'), config.plugins.FroidSetup.radioStyle))
				list.append(getConfigListEntry(_(' 礲  Spinner'), config.plugins.FroidSetup.spinnerStyle))

		#self["Picture"].show()
		self.Picture()
		self["config"].list = list
		self["config"].l.setList(list)

	def RGB(self, r, g, b):
		return r << 16 | g << 8 | b

	def cslider(self, fcolor):
		c = self['preview']
		c.fill(0, 0, 1920, 1080, fcolor)
		c.flush()

	def Picture(self):
		try:
			werty = self["config"].getCurrent()[1].value
			#bootlogo
			if werty == config.plugins.FroidSetup.bootlogoStyle.value:
				hb = "/media/hdd/Froid_Packets/bootlogos/%s.png"%(config.plugins.FroidSetup.bootlogoStyle.value)
				if os.path.exists(hb):
					path = self['Picture'].instance.setPixmapFromFile(hb)
				else:
					path = self['Picture'].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/pictures/bootlogos.png")
			#radiologo
			elif werty == config.plugins.FroidSetup.radioStyle.value:
				hr = "/media/hdd/Froid_Packets/radiologos/%s.png"%(config.plugins.FroidSetup.radioStyle.value)
				if os.path.exists(hr):
					path = self['Picture'].instance.setPixmapFromFile(hr)
				else:
					path = self['Picture'].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/pictures/bootlogos.png")
			#spinner	
			elif werty == config.plugins.FroidSetup.spinnerStyle.value:
				hs = "/media/hdd/Froid_Packets/spinners/%s/wait1.png"%(config.plugins.FroidSetup.spinnerStyle.value)
				if os.path.exists(hs):
					path = self['Picture'].instance.setPixmapFromFile(hs)
				else:
					path = self['Picture'].instance.setPixmapFromFile("/usr/share/enigma2/spinner/wait1.png")
			else:
				pic = '/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/pictures/%s.png' % werty
				path = self['Picture'].instance.setPixmapFromFile('/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/pictures/%s.png' % werty)
				#path = self['Picture'].instance.setPixmapFromFile('/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/pictures/%s' % werty)
			if os.path.exists(pic):
				self['Picture'].show()
			else:
				self['Picture'].hide()

		except:
			return ""

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.delay()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.delay()

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.delay()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.delay()

	def pageUp(self):
		self["config"].instance.moveSelection(self["config"].instance.pageDown)
		self.delay()

	def pageDown(self):
		self["config"].instance.moveSelection(self["config"].instance.pageUp)
		self.delay()
 
	def save(self):
		skn = "/usr/share/enigma2/Froid/skin.xml"
		skn_tmp = skn + ".tmp"
		for x in self["config"].list:
			if len(x) > 1:
					x[1].save()
			else:
					pass

		if config.plugins.FroidSetup.MODSAVE.value == True:
			os.system("tar -zxvf /usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/mods/%s.tar.gz -C/ "%config.plugins.FroidSetup.MOD.value) 
		else:
			self.chngd = []
			if config.plugins.FroidSetup.skin_default.value == True:
				if config.plugins.FroidSetup.minitv.value == False:
					self.chngd.append(['<screen name="pig', '<screen name="' + config.plugins.FroidSetup.onmntv.value])
					self.chngd.append(['name="back_color" value="#00151f2a', 'name="back_color" value="' + config.plugins.FroidSetup.backTransp.value + self.r])
					self.chngd.append(['panel name="movie_df', 'panel name="' + config.plugins.FroidSetup.mvminitv.value])
				else:
					self.chngd.append(['<screen name="info_ch', '<screen name="' + config.plugins.FroidSetup.infminitv.value])
					self.chngd.append(['<screen name="clk_mn', '<screen name="' + config.plugins.FroidSetup.clkminitv.value])
				self.chngd.append(['backgroundColor="title_line" size="1920,2', 'backgroundColor="title_line" size="1920,' + config.plugins.FroidSetup.titleLnSz.value])	
				if not config.plugins.FroidSetup.clockStyle.value == "analog":
					self.chngd.append(['size="720,45" font="Console; 38', 'size="720,45" font="' + config.plugins.FroidSetup.clockStyle.value])
				else:
					self.chngd.append(['panel name="clk_digi', 'panel name="clk_' + config.plugins.FroidSetup.clockStyle.value])

				self.chngd.append(['panel name="infobar_default', 'panel name="infobar_' + config.plugins.FroidSetup.infStyle.value])
				self.chngd.append(['panel name="secondinfobar_deff', 'panel name="secondinfobar_' + config.plugins.FroidSetup.SinfStyle.value])
				self.chngd.append(['panel name="ChannelSelection_def', 'panel name="ChannelSelection_' + config.plugins.FroidSetup.chStyle.value])

				if config.plugins.FroidSetup.volStyle.value == 'lume':
					self.chngd.append(['render="Label" name="Volume', 'render="Label" name="Volu' + config.plugins.FroidSetup.volStyle.value])
					self.chngd.append(['screen name="Volume2', 'screen name="Vo' + config.plugins.FroidSetup.volStyle.value])
				if config.plugins.FroidSetup.volStyle.value == 'me':
					self.chngd.append(['render="Label" name="Volume', 'render="Label" name="Vo' + config.plugins.FroidSetup.volStyle.value])
					self.chngd.append(['screen name="Volume3', 'screen name="Volu' + config.plugins.FroidSetup.volStyle.value])	
				if config.plugins.FroidSetup.volStyle.value == 'olume':
					self.chngd.append(['render="Label" name="Volume', 'render="Label" name="Vo' + config.plugins.FroidSetup.volStyle.value])
					self.chngd.append(['screen name="Volume4', 'screen name="V' + config.plugins.FroidSetup.volStyle.value])

				self.chngd.append(['panel name="history_def', 'panel name="' + config.plugins.FroidSetup.hstryStyle.value])	
				self.chngd.append(['panel name="emc_def', 'panel name="' + config.plugins.FroidSetup.emcStyle.value])	
				self.chngd.append(['weathericon', '' + config.plugins.FroidSetup.weatherStyle.value])
				self.chngd.append(['<panel name="infobar_wx', '<panel name="infobar_' + config.plugins.FroidSetup.InfweatherStyle.value])

				self.chngd.append(['panel name="EventView_evnt', 'panel name="EventView' + config.plugins.FroidSetup.eventStyle.value])
					#self.chngd.append(['name="EventView', 'name="EventView' + config.plugins.FroidSetup.eventStyle.value])
				self.chngd.append(['<panel name="rgyb_rgyb', '<panel name="rgyb' + config.plugins.FroidSetup.rgybStyle.value])
				if config.plugins.FroidSetup.rgybStyle.value == '_r4':
					self.chngd.append(['source="key_red" foregroundColor="font_color"', 'source="key_red" foregroundColor="red"'])
					self.chngd.append(['source="key_green" foregroundColor="font_color"', 'source="key_green" foregroundColor="green"'])
					self.chngd.append(['source="key_yellow" foregroundColor="font_color"', 'source="key_yellow" foregroundColor="yellow"'])
					self.chngd.append(['source="key_blue" foregroundColor="font_color"', 'source="key_blue" foregroundColor="blue"'])
					
					self.chngd.append(['name="key_red" foregroundColor="font_color"', 'name="key_red" foregroundColor="red"'])
					self.chngd.append(['name="key_green" foregroundColor="font_color"', 'name="key_green" foregroundColor="green"'])
					self.chngd.append(['name="key_yellow" foregroundColor="font_color"', 'name="key_yellow" foregroundColor="yellow"'])
					self.chngd.append(['name="key_blue" foregroundColor="font_color"', 'name="key_blue" foregroundColor="blue"'])
					
					self.chngd.append(['name="red" foregroundColor="font_color"', 'name="red" foregroundColor="red"'])
					self.chngd.append(['name="green" foregroundColor="font_color"', 'name="green" foregroundColor="green"'])
					self.chngd.append(['name="yellow" foregroundColor="font_color"', 'name="yellow" foregroundColor="yellow"'])
					self.chngd.append(['name="blue" foregroundColor="font_color"', 'name="blue" foregroundColor="blue"'])

				if config.plugins.FroidSetup.selLine.value == True:
					self.chngd.append(['pos="bpTop" filename="Froid/selline/top_line.png', 'pos="bpTop" filename="Froid/selline/top_' + config.plugins.FroidSetup.selLineTop.value + ".png" ])
					self.chngd.append(['pos="bpLeft" filename="Froid/selline/left_line.png', 'pos="bpLeft" filename="Froid/selline/left_'  + config.plugins.FroidSetup.selLineLeft.value + ".png"])
					self.chngd.append(['pos="bpRight" filename="Froid/selline/right_line.png', 'pos="bpRight" filename="Froid/selline/right_'   + config.plugins.FroidSetup.selLineRight.value + ".png"])
					self.chngd.append(['pos="bpBottom" filename="Froid/selline/bottom_line.png', 'pos="bpBottom" filename="Froid/selline/bottom_'  + config.plugins.FroidSetup.selLineBottom.value + ".png" ])
				
				self.chngd.append(['<panel name="Hmenu_center', '<panel name="Hmenu_' + config.plugins.FroidSetup.hmnStyle.value])
				self.chngd.append(['<panel name="Hmenuicon_center', '<panel name="Hmenuicon_' + config.plugins.FroidSetup.hmnStyle.value])
				# bootlogos
				if config.plugins.FroidSetup.bootlogoStyle.value == 'bdef':
					if os.path.islink("/usr/share/bootlogo.mvi"):
						os.unlink("/usr/share/bootlogo.mvi")
						if os.path.exists("/usr/share/bootlogox.mvi"):
							os.rename("/usr/share/bootlogox.mvi", "/usr/share/bootlogo.mvi")
				else:
					if os.path.exists("/usr/share/bootlogo.mvi"):
						if os.path.exists("/media/hdd/Froid_Packets/bootlogos/%s.mvi"%(config.plugins.FroidSetup.bootlogoStyle.value)):
							os.rename("/usr/share/bootlogo.mvi", "/usr/share/bootlogox.mvi")
							boot_cur =  "/usr/share/bootlogo.mvi"
							boot_new = "/media/hdd/Froid_Packets/bootlogos/%s.mvi"%(config.plugins.FroidSetup.bootlogoStyle.value)
							os.symlink(boot_new, boot_cur)

				# radio bakcgrounds
				if config.plugins.FroidSetup.radioStyle.value == 'rdef':
					if os.path.islink("/usr/share/enigma2/radio.mvi"):
						os.unlink("/usr/share/enigma2/radio.mvi")
						if os.path.exists("/usr/share/enigma2/radiox.mvi"):
							os.rename("/usr/share/enigma2/radiox.mvi", "/usr/share/enigma2/radio.mvi")
				else:
					if os.path.exists("/usr/share/enigma2/radio.mvi"):
						if os.path.exists("/media/hdd/Froid_Packets/radios/%s.mvi"%(config.plugins.FroidSetup.radioStyle.value)):
							os.rename("/usr/share/enigma2/radio.mvi", "/usr/share/enigma2/radiox.mvi")
							rd_cur =  "/usr/share/enigma2/radio.mvi"
							rd_new = "/media/hdd/Froid_Packets/radios/%s.mvi"%(config.plugins.FroidSetup.radioStyle.value)
							os.symlink(rd_new, rd_cur)
				# spinners
				if not config.plugins.FroidSetup.spinnerStyle.value == 'sdef':
					if os.path.isdir("/media/hdd/Froid_Packets/spinners"):
						#os.rename("/usr/share/enigma2/Froid/spinnerx", "/usr/share/enigma2/Froid/spinner")
						if not os.path.isdir("/usr/share/enigma2/Froid/spinner"):
							os.mkdir("/usr/share/enigma2/Froid/spinner")
							copy_tree("/media/hdd/Froid_Packets/spinners/%s/"%(config.plugins.FroidSetup.spinnerStyle.value), "/usr/share/enigma2/Froid/spinner/")
						else:
							shutil.rmtree("/usr/share/enigma2/Froid/spinner")
							os.mkdir("/usr/share/enigma2/Froid/spinner")
							copy_tree("/media/hdd/Froid_Packets/spinners/%s/"%(config.plugins.FroidSetup.spinnerStyle.value), "/usr/share/enigma2/Froid/spinner/")
				else:
					if os.path.isdir("/usr/share/enigma2/Froid/spinner"):
						shutil.rmtree("/usr/share/enigma2/Froid/spinner")

				if not config.plugins.FroidSetup.Colored.value == "DEFAULT":
					r = int(config.plugins.FroidSetup.colorR.value)
					g = int(config.plugins.FroidSetup.colorG.value)
					b = int(config.plugins.FroidSetup.colorB.value)
					rgb = '{:02x}{:02x}{:02x}'.format(r, g, b)
					self.chngd.append(['name="back_color" value="#00151f2a', 'name="back_color" value="#00' + rgb])

					r2 = int(config.plugins.FroidSetup.colorR2.value)
					g2 = int(config.plugins.FroidSetup.colorG2.value)
					b2 = int(config.plugins.FroidSetup.colorB2.value)
					rgb2 = '{:02x}{:02x}{:02x}'.format(r2, g2, b2)
					self.chngd.append(['name="title_back" value="#002b3947', 'name="title_back" value="#00' + rgb2])

					r2a = int(config.plugins.FroidSetup.colorR2a.value)
					g2a = int(config.plugins.FroidSetup.colorG2a.value)
					b2a = int(config.plugins.FroidSetup.colorB2a.value)
					rgb2a = '{:02x}{:02x}{:02x}'.format(r2a, g2a, b2a)
					self.chngd.append(['name="title_color" value="#00c5c5c5', 'name="title_color" value="#00' + rgb2a])

					r2b = int(config.plugins.FroidSetup.colorR2b.value)
					g2b = int(config.plugins.FroidSetup.colorG2b.value)
					b2b = int(config.plugins.FroidSetup.colorB2b.value)
					rgb2b = '{:02x}{:02x}{:02x}'.format(r2b, g2b, b2b)
					self.chngd.append(['name="title_line" value="#00151f2a', 'name="title_line" value="#00' + rgb2b])

					r3 = int(config.plugins.FroidSetup.colorR3.value)
					g3 = int(config.plugins.FroidSetup.colorG3.value)
					b3 = int(config.plugins.FroidSetup.colorB3.value)
					rgb3 = '{:02x}{:02x}{:02x}'.format(r3, g3, b3)
					self.chngd.append(['name="other_line" value="#005a5a5a', 'name="other_line" value="#00' + rgb3])

					r4 = int(config.plugins.FroidSetup.colorR4.value)
					g4 = int(config.plugins.FroidSetup.colorG4.value)
					b4 = int(config.plugins.FroidSetup.colorB4.value)
					rgb4 = '{:02x}{:02x}{:02x}'.format(r4, g4, b4)
					self.chngd.append(['name="sel" value="#00354455', 'name="sel" value="#00' + rgb4])

					r5 = int(config.plugins.FroidSetup.colorR5.value)
					g5 = int(config.plugins.FroidSetup.colorG5.value)
					b5 = int(config.plugins.FroidSetup.colorB5.value)
					rgb5 = '{:02x}{:02x}{:02x}'.format(r5, g5, b5)
					self.chngd.append(['name="prgrs" value="#004c5d70', 'name="prgrs" value="#00' + rgb5])

					r5a = int(config.plugins.FroidSetup.colorR5a.value)
					g5a = int(config.plugins.FroidSetup.colorG5a.value)
					b5a = int(config.plugins.FroidSetup.colorB5a.value)
					rgb5a = '{:02x}{:02x}{:02x}'.format(r5a, g5a, b5a)
					self.chngd.append(['name="prgrs_sel" value="#00c5c5c5', 'name="prgrs_sel" value="#00' + rgb5a])

					r6 = int(config.plugins.FroidSetup.colorR6.value)
					g6 = int(config.plugins.FroidSetup.colorG6.value)
					b6 = int(config.plugins.FroidSetup.colorB6.value)
					rgb6 = '{:02x}{:02x}{:02x}'.format(r6, g6, b6)
					self.chngd.append(['name="scrlbr_color" value="#005a5a5a', 'name="scrlbr_color" value="#00' + rgb6])

					r7 = int(config.plugins.FroidSetup.colorR7.value)
					g7 = int(config.plugins.FroidSetup.colorG7.value)
					b7 = int(config.plugins.FroidSetup.colorB7.value)
					rgb7 = '{:02x}{:02x}{:02x}'.format(r7, g7, b7)
					self.chngd.append(['name="font_color" value="#00c5c5c5', 'name="font_color" value="#00' + rgb7])

					r8 = int(config.plugins.FroidSetup.colorR8.value)
					g8 = int(config.plugins.FroidSetup.colorG8.value)
					b8 = int(config.plugins.FroidSetup.colorB8.value)
					rgb8 = '{:02x}{:02x}{:02x}'.format(r8, g8, b8)
					self.chngd.append(['name="font_color_sel" value="#00ffffff', 'name="font_color_sel" value="#00' + rgb8])

					r9 = int(config.plugins.FroidSetup.colorR9.value)
					g9 = int(config.plugins.FroidSetup.colorG9.value)
					b9 = int(config.plugins.FroidSetup.colorB9.value)
					rgb9 = '{:02x}{:02x}{:02x}'.format(r9, g9, b9)
					self.chngd.append(['name="rgyb_back" value="#002b3948', 'name="rgyb_back" value="#00' + rgb9])

					r10 = int(config.plugins.FroidSetup.colorR10.value)
					g10 = int(config.plugins.FroidSetup.colorG10.value)
					b10 = int(config.plugins.FroidSetup.colorB10.value)
					rgb10 = '{:02x}{:02x}{:02x}'.format(r10, g10, b10)
					self.chngd.append(['name="clock_color" value="#00c5c5c5', 'name="clock_color" value="#00' + rgb10])

					r12 = int(config.plugins.FroidSetup.colorR12.value)
					g12 = int(config.plugins.FroidSetup.colorG12.value)
					b12 = int(config.plugins.FroidSetup.colorB12.value)
					rgb12 = '{:02x}{:02x}{:02x}'.format(r12, g12, b12)
					self.chngd.append(['name="csd" value="#00a0a0a0', 'name="csd" value="#00' + rgb12])
					
					r12a = int(config.plugins.FroidSetup.colorR12a.value)
					g12a = int(config.plugins.FroidSetup.colorG12a.value)
					b12a = int(config.plugins.FroidSetup.colorB12a.value)
					rgb12a = '{:02x}{:02x}{:02x}'.format(r12a, g12a, b12a)
					self.chngd.append(['name="csd_sel" value="#00c5c5c5', 'name="csd_sel" value="#00' + rgb12a])
					
					r13 = int(config.plugins.FroidSetup.colorR13.value)
					g13 = int(config.plugins.FroidSetup.colorG13.value)
					b13 = int(config.plugins.FroidSetup.colorB13.value)
					rgb13 = '{:02x}{:02x}{:02x}'.format(r13, g13, b13)
					self.chngd.append(['name="key_color" value="#00778899', 'name="key_color" value="#00' + rgb13])

					r14 = int(config.plugins.FroidSetup.colorR14.value)
					g14 = int(config.plugins.FroidSetup.colorG14.value)
					b14 = int(config.plugins.FroidSetup.colorB14.value)
					rgb14 = '{:02x}{:02x}{:02x}'.format(r14, g14, b14)
					self.chngd.append(['name="inf_info" value="#0020b2aa', 'name="inf_info" value="#00' + rgb14])

			else:
				dskn = open('/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/skin.xml', 'r').read()
				fskn = '/usr/share/enigma2/Froid/skin.xml'
				d = open(fskn, 'w').write(dskn)

			self.aS("/usr/lib/enigma2/python/Plugins/Extensions/FroidSetup/skin.xml")

			t = open(skn_tmp, "w")
			for i in self.skin_lines:
				t.writelines(i)
			t.close()

			s = open(skn,"w")
			for line in open(skn_tmp):
				s.write(line)
			s.close()

			remove('%s'%(skn_tmp))
			configfile.save()
		self.restart()

	def aS(self, appendFileName, skinPart_sr=None):

		skFile = open(appendFileName, "r")
		file_lines = skFile.readlines()
		skFile.close()

		tmp_sr = []
		if skinPart_sr is not None:
			tmp_sr = self.chngd + skinPart_sr
		else:
			tmp_sr = self.chngd

		for skinLine in file_lines:
			for item in tmp_sr:
				skinLine = skinLine.replace(item[0], item[1])
			self.skin_lines.append(skinLine)

	def about(self):
		self.session.open(FroidAbout)

	def downloads(self):
		self.session.open(dPackets)

	def UpdateSkin(self):
		urllib.urlretrieve('https://raw.githubusercontent.com/digiteng/store/master/FroidSkinUpdate/ipk.version', '/usr/share/enigma2/Froid/ipk.version')
		sknver = open('/usr/share/enigma2/Froid/skin.version', 'r').read()
		ver_ipk = open('/usr/share/enigma2/Froid/ipk.version', 'r').read()

		if ver_ipk > sknver:
			urllib.urlretrieve("https://raw.githubusercontent.com/digiteng/store/master/FroidSkinUpdate/version_info.txt", '/tmp/version_info.txt')
			vinfo = open("/tmp/version_info.txt", "r").read()
			self.session.openWithCallback(self.ipkDownload, MessageBox,_("Current version..: %s\nNew version.......: %s \n\nNew version skin available !..\n\n%s\nDo you want  UPDATE SKIN ?.."%(sknver,ver_ipk,vinfo)), MessageBox.TYPE_YESNO)
		else:
			self.session.open(MessageBox, _("NO NEW VERSION !.."), MessageBox.TYPE_INFO, timeout = 10)

	def ipkDownload(self, answer):
		if answer:
			ver_ipk = open('/usr/share/enigma2/Froid/ipk.version', 'r').read()
			urlipk = "enigma2-plugin-skins-froid_%s_all.ipk" %(ver_ipk) 
			#url1 = "enigma2-plugin-skins-froid_%s_all.ipk?raw=true"%(ver_ipk)
			url = "https://github.com/digiteng/store/blob/master/FroidSkinUpdate/enigma2-plugin-skins-froid_%s_all.ipk?raw=true"%(ver_ipk)
			open('/tmp/ipkName', 'w').write(urlipk)
			open('/tmp/urlDownload', 'w').write(url)
			ipk_name = open('/tmp/ipkName', 'r').read()
			url_download = open('/tmp/urlDownload', 'r').read()
			urllib.urlretrieve(url_download, "/tmp/%s" % ipk_name)

			cmdList = []
			ipktmp = "/tmp/%s" %(ipk_name)
			cmdList.append((IpkgComponent.CMD_INSTALL, {"package": ipktmp}))
			self.session.openWithCallback(self.updateFinish, Ipkg, cmdList = cmdList)

			remove('/tmp/ipkName')
			remove('/tmp/urlDownload')

	def updateFinish(self):	
		self.session.openWithCallback(self.restarte2, MessageBox, _("GUI needs a restart to apply a new skin.\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)

	def restarte2(self, answer):
		if answer:
			self.session.open(TryQuitMainloop, 3)

	def restart(self):
		configfile.save()
		self.session.openWithCallback(self.e2restart,MessageBox,_("GUI needs a restart to apply a new skin.\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)

	def e2restart(self, answer):
		if answer is True:
			config.skin.save()
			configfile.save()
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close()

	def exit(self):
		os.system('rm -rf /media/hdd/temp/')
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
			else:
					pass
					
		self.close()

class dPackets(Screen):

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		self['updt-b'] = Label(_('-'))
		self['updt-r'] = Label(_('-'))
		self['updt-s'] = Label(_('-'))
		list = []
		list.append((_('Bootlogo Packets'), 'btlg'))
		list.append((_('Radio Background Packets'), 'rd'))
		list.append((_('Spinner Packets'), 'sp'))
		self['elist'] = MenuList(list)

		self['myActionMap'] = ActionMap(["OkCancelActions", "SetupActions"],{'ok': self.keyOk, 'cancel': self.close}, -1)

		if os.path.ismount('/media/hdd'):
			if not os.path.isdir('/media/hdd/temp'):
				os.mkdir('/media/hdd/temp')
			if not os.path.isdir('/media/hdd/Froid_Packets'):
				os.mkdir('/media/hdd/Froid_Packets')

		self.pckt_old = "/media/hdd/Froid_Packets/pckt_version"
		self.pckt = "https://github.com/digiteng/store/raw/master/FroidSkinUpdate/Froid_Packets/pckt_version"
		if not os.path.exists("/media/hdd/Froid_Packets/pckt_version"):
			urllib.urlretrieve(self.pckt, self.pckt_old)

		self['progress'] = ProgressBar()
		self['progress'].setRange((0, 100))
		self['progress'].setValue(0)
		self['status'] = Label(_("-"))
		self.delay = eTimer()
		self.delay.start(100, True)
		self.delay.callback.append(self.upchck)

	def keyOk(self):
		self.delay.callback.append(self.dp)
		self.delay.start(100, True)

	def dp(self):
		returnValue = self['elist'].l.getCurrentSelection()[1]
		if returnValue is not None:
			if returnValue is 'btlg':
				self.dwnld('bootlogos')
			elif returnValue is 'rd':
				self.dwnld('radiologos')
			elif returnValue is 'sp':
				self.dwnld('spinners')
			else:
				self.close(None)

	def dwnld(self, entry):
		os.system('rm -rf /media/hdd/Froid_Packets/%s/'% (entry))
		self.dwn = '/media/hdd/temp/%s.zip'%(entry)
		self.url = 'https://github.com/digiteng/store/raw/master/FroidSkinUpdate/Froid_Packets/%s.zip'%(entry)
		self.download = downloadWithProgress(self.url, self.dwn)
		self.download.addProgress(self.downloadProgress)
		self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)

	def downloadProgress(self, current, total):
		self['progress'].setValue(int(100*current/total))
		self['status'].setText('Downloading... ' + str(int(100*current/total)) + '%' + ' ' + ("( %.1f / %.1f MB )")%(current/1024.0/1024.0, total/1024.0/1024.0))

	def downloadFailed(self, failure_instance=None, error_message=''):
		text = _('Error !')
		if error_message == '' and failure_instance is not None:
			error_message = failure_instance.getErrorMessage()
			text += ' : ' + error_message
		self['status'].setText(text)

	def downloadFinished(self, total, string=''):
		self['status'].setText(_('Download successfully !..'))
		self.unzip("")

	def unzip(self, entry):
		if os.path.exists(self.dwn):
			with ZipFile(self.dwn, 'r') as z:
				z.extractall("/media/hdd/Froid_Packets/")
				#os.system('rm -rf ' + self.dwn)
				self.wrt("")

	def wrt(self, entry):
		if os.path.exists(self.dwn):
			if self.dwn == "/media/hdd/temp/bootlogos.zip":
				self['updt-b'].hide()
			if self.dwn == "/media/hdd/temp/radiologos.zip":
				self['updt-r'].hide()
			if self.dwn == "/media/hdd/temp/spinners.zip":
				self['updt-s'].hide()

		if len(self.upd) == len(os.listdir("/media/hdd/temp/")):
			urllib.urlretrieve(self.pckt, self.pckt_old)

	def upchck(self):
		self.us = urllib2.urlopen(self.pckt)
		self.cs = open("/media/hdd/Froid_Packets/pckt_version", "r")
		import difflib
		self.diff = difflib.ndiff(self.us.readlines(), self.cs.readlines())
		self.upd = ''.join(x[2] for x in self.diff if x.startswith('+ '))
		for b in self.upd:
			if b == "b":
				self['updt-b'].setText(_("礲"))
				if os.path.exists("/media/hdd/temp/bootlogos.zip"):
					self['updt-b'].hide()
		for r in self.upd:
			if r == "r":
				self['updt-r'].setText(_("礲"))
				if os.path.exists("/media/hdd/temp/radiologos.zip"):
					self['updt-r'].hide()
		for s in self.upd:
			if s == "s":
				self['updt-s'].setText(_("礲"))
				if os.path.exists("/media/hdd/temp/spinners.zip"):
					self['updt-s'].hide()
		if len(self.upd) == 0:
			if os.path.exists("/media/hdd/temp"):
				if len(os.listdir("/media/hdd/temp/")) == 0:
					urllib.urlretrieve(self.pckt, self.pckt_old)
