# by digiteng...12-2019
#  <widget source="session.CurrentService" render="Label" position="50,545" size="930,40" font="Regular; 32" halign="left" transparent="1" zPosition="2" backgroundColor="back_color" valign="center">
#   	<convert type="pngR">AV</convert>
# </widget>
from Components.Converter.Converter import Converter
from Components.Element import cached

class pngR(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):
		if self.type == "pngRn":
			return " "

	text = property(getText)
