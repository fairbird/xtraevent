#Coders by Nikolasi
#ver. 3
# -*- coding: UTF-8 -*-

#for picons stars:
      #<widget source="ServiceEvent" render="Ratingvs" position="96,282" zPosition="6" size="210,21" transparent="1" alphatest="on">
      #<convert type="EventName">Name</convert>
     # </widget>
#for posters:     
     #<widget source="ServiceEvent" render="Ratingvs" mode="poster" position="1100,57" zPosition="6" size="124,170" transparent="1" alphatest="on">
    # <convert type="EventName">Name</convert>
     #</widget>     
from Renderer import Renderer
from enigma import ePixmap, ePicLoad
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename

class Ratingvs(Renderer):
	__module__ = __name__
	searchPaths = ('/usr/share/enigma2/%s/', '/media/hdd/%s/', '/media/usb/%s/', '/media/USB/%s/')
	searchPaths2 = ('/media/hdd/VPoiske/%s/', '/media/usb/VPoiske/%s/')
	def __init__(self):
		Renderer.__init__(self)
		self.path = 'starsbar'
		self.path2 = 'posters'
		self.mode = 'rating'
		self.nameCache = {}
		self.pngname = ''
		self.pngname2 = ""
		self.picon = ePicLoad()

	def applySkin(self, desktop, parent):
		attribs = []
		for (attrib, value,) in self.skinAttributes:
			if attrib == 'path':
				self.path = value
			elif attrib == 'mode':
				self.mode = value
			else:
				attribs.append((attrib, value))
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)
		
	GUI_WIDGET = ePixmap
	
	def changed(self, what):
                name2 = ""
                sname = "" 
                all = ""
                namerating = "n/a"
                namekpcode = "n/a"                 
		if self.instance:
			pngname = ''
			if (what[0] != self.CHANGED_CLEAR):
				name2 = self.source.text
				if name2 != "":
				        all = self.reed(name2)
				if "," in all:
                                        namerating, namekpcode = all.split(",")
				if self.mode == 'rating':
				        sname = namerating
				else:
                                        sname = namekpcode
				pngname = self.nameCache.get(sname, '')
				if (pngname == ''):
					pngname = self.findPicon(sname)
					if (pngname != ''):
						self.nameCache[sname] = pngname
			if (pngname == ''):
                                if self.mode == 'rating':
				     pngname = self.nameCache.get('00', '')
				     if (pngname == ''):
                                             pngname = self.findPicon('00')
					     self.nameCache['00'] = pngname
				else:
                                        pngname = self.findPicon('picon_default')
                                        if (pngname == ''):
					    tmp = '/usr/lib/enigma2/python/Plugins/Extensions/VPoiske/picon_default.png'
					    if fileExists(tmp):
						    pngname = tmp
					    self.nameCache['default'] = pngname                                        
			if (self.pngname != pngname):
                                if self.mode == 'rating':
				        self.instance.setPixmapFromFile(pngname)
				        self.pngname = pngname
				else:
			                self.pngname = pngname
			                self.instance.setScale(1)
			                size = self.instance.size()
                                        self.picon.setPara((size.width(), size.height(), 1, 1, False, 1, '#00000000'))
                                        self.picon.startDecode(self.pngname, 0, 0, False)               
                                        self.png = self.picon.getData()				
	                                self.instance.setPixmap(self.png)                                        
		

	def reed(self, name):
            rating = ""
            name2 = ""
            namerating = ""
            namekpcode = ""            
            data = "/usr/lib/enigma2/python/Plugins/Extensions/VPoiske/data/rated.vp"
            if fileExists(data):
                    watchvideopage = open(data)    
                    content = watchvideopage.read()
                    watchvideopage.close()
                    alls = content.split('----------------------------------------------------------------------------------------------------')
                    for all in alls:
                            if name in all:
                                    results = all.split()
                                    for result in results:
                                            if 'rating:' in result:
                                                    name2 = '%s' % (result)
                                                    namerating = name2.replace('rating:', '').strip()
                                                    if namerating != "0" or namerating != "":
                                                            namerating = namerating[:-1]
                                                    else:
                                                         namerating = "00"                                                              
                                            if 'kpcode' in result:
                                                    name2 = '%s' % (result)
                                                    if namekpcode != "0":
                                                        namekpcode = name2.replace('kpcode:', '').strip()
                                                    else:
                                                         namekpcode = ""   
                                    rating = '%s,%s' % (namerating, namekpcode)        
            return rating
					
	def findPicon(self, serviceName):
                IMAGE_PATH2 = resolveFilename(SCOPE_CURRENT_SKIN, 'starsbar')
                path2 = resolveFilename(SCOPE_SKIN_IMAGE, IMAGE_PATH2)                
                if self.mode == 'rating':
                        if fileExists(path2):
                                pngname = ((path2 + "/" + serviceName) + ".png")
			        if fileExists(pngname):
				        return pngname
		        else:	
		                for path in self.searchPaths:
			                pngname = (((path % self.path) + serviceName) + ".png")
			                if fileExists(pngname):
				                return pngname                        
                else:
		        for path in self.searchPaths2:
			       pngname = (((path % self.path2) + serviceName) + '.jpg')
			       if fileExists(pngname):
				        return pngname
		return ''	
	
